# pyBESS
Energy Arbitrage for Battery Energy Storage Systems (BESS's)